You have to have Tk installed to run this, I'm not sure what the minimum version is that you need. But enjoy the game. 

-Robin
